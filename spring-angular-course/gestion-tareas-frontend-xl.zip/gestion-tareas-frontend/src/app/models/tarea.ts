export class Tarea {

    id?:number;
    titulo?:string;
    descripcion?:string;
    completado?:boolean;

}
