package com.edgz.encuestas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncuestasApplicationTests {

	@Test
	void contextLoads() {
	}

}
